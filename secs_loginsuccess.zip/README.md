"# secs" 
