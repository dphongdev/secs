module.exports = {
    homeUrl:'https://net-ga.admin.12365.bpx-cdn.cloud/',
    loginUrl:'https://net-ga.admin.12365.bpx-cdn.cloud/api/admin/login',
    adminUrl:'https://net-ga.admin.12365.bpx-cdn.cloud/admin',
    username:'gadev',
    password:'gaSelamatPagi',
    headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:24.0) Gecko/20100101 Firefox/24.0',
    },
    pKey:'-----BEGIN RSA PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCsr6md5JQfMYdD\x2bgp8GclZBmJg\ndAKTjX\/fqT8k2cH8aYkiDCNhP4w\x2b5I\x2bfJNsTZOcK6Id\x2bXoCSy\x2bjz9q6G4BSnsbDd\nHM5sEh\/3iHwYZXFEs70\/BlMKv7I61ixii2aWEfne3m\/u33t6uTL4LKWqmpXc3iuP\nwWXkKptVqkl13fD3GwIDAQAB\n-----END RSA PUBLIC KEY-----\n',
}